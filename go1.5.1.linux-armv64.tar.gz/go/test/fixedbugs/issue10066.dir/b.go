package b

import "./a"

func test() {
	a.Do()
}
