// rundir

// Copyright 2012 The Go Authors.  All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Issue 4252: tests that fixing the issue still allow
// builtins to be redeclared and are not corrupted
// in export data.

package ignored
